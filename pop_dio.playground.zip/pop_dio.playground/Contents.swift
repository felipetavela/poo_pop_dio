import UIKit

protocol ExercicioFisico {
    var nome: String { get }
    var caloriasQueimadasPorMinuto: Double { get }
    func fazerExercicio(minutos: Int)
}

struct Futebol: ExercicioFisico {
    let nome = "Futebol"
    let caloriasQueimadasPorMinuto = 10.0
    
    func fazerExercicio(minutos: Int) {
        let calorias = caloriasQueimadasPorMinuto * Double(minutos)
        print("\(nome) por \(minutos) minutos queima \(calorias) calorias.")
    }
}

struct Natação: ExercicioFisico {
    let nome = "Natação"
    let caloriasQueimadasPorMinuto = 8.0
    
    func fazerExercicio(minutos: Int) {
        let calorias = caloriasQueimadasPorMinuto * Double(minutos)
        print("\(nome) por \(minutos) minutos queima \(calorias) calorias.")
    }
}

func executarExercicios(exercicios: [ExercicioFisico], minutos: Int) {
    for exercicio in exercicios {
        exercicio.fazerExercicio(minutos: minutos)
    }
}

let futebol = Futebol()
let nado = Natação()

let exercicios: [ExercicioFisico] = [nado, futebol]
executarExercicios(exercicios: exercicios, minutos: 30)
